document.addEventListener('DOMContentLoaded', function () {
    const LoginForm = document.getElementById('LoginForm');

    if (LoginForm) {
        LoginForm.addEventListener('submit', function (event) {
            event.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (username === 'staffmember' && password === 'letmein!123') {
                window.location.href = 'ITrequestform.html';
            } else if (username === 'admin' && password === 'heretohelp!456') {
                window.location.href = 'technician-portal.html';
            } else {
                alert('Invalid username or password.');
            }
        });
    }
});

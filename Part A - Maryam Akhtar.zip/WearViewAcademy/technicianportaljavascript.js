document.addEventListener('DOMContentLoaded', function () {
    // Function to fetch incomplete requests from the server
    function fetchIncompleteRequests() {
        fetch('fetch-incomplete-requests.php')
            .then(response => response.json())
            .then(data => {
                incompleteRequests = data;
                populateIncompleteRequests();
            })
            .catch(error => console.error('Error fetching incomplete requests:', error));
    }

    // Function to fetch complete requests from the server
    function fetchCompleteRequests() {
        fetch('fetch-complete-requests.php')
            .then(response => response.json())
            .then(data => {
                completeRequests = data;
                populateCompleteRequests();
            })
            .catch(error => console.error('Error fetching complete requests:', error));
    }

    // Placeholder data for incomplete and complete requests
    let incompleteRequests = [];
    let completeRequests = [];

    // Function to populate incomplete requests
    function populateIncompleteRequests() {
        const tbody = document.querySelector('#incomplete-requests tbody');
        tbody.innerHTML = '';
        incompleteRequests.forEach(request => {
            const tr = createRequestRow(request, 'Incomplete');
            tbody.appendChild(tr);
        });
    }

    // Function to populate complete requests
    function populateCompleteRequests() {
        const tbody = document.querySelector('#complete-requests tbody');
        tbody.innerHTML = '';
        completeRequests.forEach(request => {
            const tr = createRequestRow(request, 'Complete');
            tbody.appendChild(tr);
        });
    }

    // Function to create a table row for a request
    function createRequestRow(request, status) {
        const tr = document.createElement('tr');
        tr.dataset.id = request.id;
        tr.innerHTML = `
            <td>${request.name}</td>
            <td>${request.email}</td>
            <td>${request.location}</td>
            <td>${request.description}</td>
            <td>
                <select class="status-select" data-status="${status}">
                    <option value="Incomplete"${status === 'Incomplete' ? ' selected' : ''}>Incomplete</option>
                    <option value="Complete"${status === 'Complete' ? ' selected' : ''}>Complete</option>
                </select>
            </td>
        `;
        return tr;
    }

    // Event listener for status change
    document.addEventListener('change', function (event) {
        if (event.target.classList.contains('status-select')) {
            const selectedOption = event.target.options[event.target.selectedIndex];
            const newStatus = selectedOption.value;
            const requestId = parseInt(event.target.closest('tr').dataset.id, 10);

            if (newStatus === 'Complete' || newStatus === 'Incomplete') {
                // Update status in the database via AJAX
                fetch(`update-request-status.php?id=${requestId}&status=${newStatus}`)
                    .then(response => response.text())
                    .then(() => {
                        // After successful update, move the row to the appropriate table
                        moveRequestToSection(requestId, newStatus);
                    })
                    .catch(error => console.error('Error updating request status:', error));
            }
        }
    });

    // Function to move request row between tables
    function moveRequestToSection(requestId, newStatus) {
        const requestRow = document.querySelector(`#incomplete-requests tr[data-id="${requestId}"]`) ||
                            document.querySelector(`#complete-requests tr[data-id="${requestId}"]`);
        if (!requestRow) return;

        const statusSelect = requestRow.querySelector('.status-select');
        if (!statusSelect) return;

        // Find the target table based on the new status
        const currentTable = requestRow.closest('table');
        const targetTableId = (newStatus === 'Complete') ? 'complete-requests' : 'incomplete-requests';
        const targetTable = document.getElementById(targetTableId);
        if (!targetTable) return;

        // Move the row to the target table if it's not already there
        if (currentTable !== targetTable) {
            targetTable.querySelector('tbody').appendChild(requestRow);
            statusSelect.setAttribute('data-status', newStatus);
        }
    }

    // Initial population of requests
    fetchIncompleteRequests();
    fetchCompleteRequests();
});

<?php
// Database connection variables
$servername = "localhost";
$username = "WearViewAcademy";
$password = "12Jeff34!";
$database = "WearViewAcademy";

try {
    // Establish database connection using PDO
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Function to fetch incomplete IT requests
    function fetchIncompleteRequests($conn) {
        $stmt = $conn->prepare("SELECT * FROM t_itrequest WHERE status = 'Incomplete'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fetch incomplete requests
    $incompleteRequests = fetchIncompleteRequests($conn);

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<?php
// Database connection variables 
$servername = "localhost";
$username = "WearViewAcademy";
$password = "12Jeff34!";
$database = "WearViewAcademy";

try {
    // Establish database connection using PDO
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the request is to update status
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? $_POST['id'] : null;
        $status = isset($_POST['status']) ? $_POST['status'] : null;

        if ($id && $status) {
            // Prepare SQL statement to update status
            $stmt = $conn->prepare("UPDATE t_itrequest SET status = :status WHERE id = :id");
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':id', $id);

            // Execute the statement
            if ($stmt->execute()) {
                echo "Request status updated successfully";
            } else {
                echo "Error updating request status";
            }
        } else {
            echo "Error: ID and status are required.";
        }
    }
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

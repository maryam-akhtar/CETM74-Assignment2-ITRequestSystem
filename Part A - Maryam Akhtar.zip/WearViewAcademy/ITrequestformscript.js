// ITrequestformscript.js

document.getElementById('it-request-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const location = document.getElementById('location').value;
    const description = document.getElementById('description').value;
    
    if (!name || !email || !location || !description) {
        alert('All fields are required!');
        return;
    }
    
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address!');
        return;
    }
    
    this.submit();
    
    document.getElementById('confirmation').classList.remove('hidden');
    document.getElementById('popup').classList.remove('hidden');
});

document.getElementById('close-popup').addEventListener('click', function() {
    document.getElementById('popup').classList.add('hidden');
});

<?php
  // Database connection variables 
  $servername = "localhost:3306"; 
  $username = "WearViewAcademy";
  $password = "12Jeff34!";
  $database = "WearViewAcademy";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 24, 2024 at 03:30 PM
-- Server version: 10.3.28-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WearViewAcademy`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_itrequest`
--

CREATE TABLE `t_itrequest` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Incomplete',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_itrequest`
--

INSERT INTO `t_itrequest` (`id`, `name`, `email`, `location`, `description`, `status`, `created_at`) VALUES
(1, 'Maryam', 'maryamakhtar897@hotmail.com', 'Birmingham', 'TESTING TESTING', 'Complete', '2024-06-22 21:37:50'),
(6, 'Saarah', 'saarah@wearviewacademy.com', 'Classroom 5, Floor 2', 'The projector is not working and does not switch on. ', 'Complete', '2024-06-22 21:56:02'),
(7, 'Hannah', 'hannah@wearviewacademy.com', 'Classroom 2, Floor 1', 'HDMI cable is broken.', 'Incomplete', '2024-06-22 21:57:15'),
(8, 'Donald', 'Donald@wearviewacademy.com', 'Classroom 8, Floor 2', 'Speakers not connecting, seems like the wires are damaged. ', 'Incomplete', '2024-06-22 21:58:15'),
(9, 'Henry', 'henry@wearviewacademy.com', 'Classroom 3, Floor 1', 'Interactive whiteboard not responding. Tried turning off and switching back on, but still not working.', 'Incomplete', '2024-06-23 13:42:23'),
(10, 'Juliet', 'juliet@wearviewacademy.com', 'Classroom 6, Floor 2', 'Can\'t seem to access the shared drive/folders.', 'Incomplete', '2024-06-23 13:43:20'),
(11, 'Tom', 'tom@wearviewacademy.com', 'Classroom 4, Floor 1', 'TEST TEST', 'Incomplete', '2024-06-23 14:06:12'),
(12, 'Maryam Akhtar', 'maryamakhtar@wearviewacademy.com', 'Classroom 9', 'TESTING', 'Incomplete', '2024-06-23 14:06:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_itrequest`
--
ALTER TABLE `t_itrequest`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_itrequest`
--
ALTER TABLE `t_itrequest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

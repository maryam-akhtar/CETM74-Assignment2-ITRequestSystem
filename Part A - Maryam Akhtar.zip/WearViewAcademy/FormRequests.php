<?php
// Database connection variables 
$servername = "localhost";
$username = "WearViewAcademy";
$password = "12Jeff34!";
$database = "WearViewAcademy";

try {
    // Establish database connection using PDO
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form was submitted via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve form data
        $name = isset($_POST['name']) ? $_POST['name'] : null;
        $email = isset($_POST['email']) ? $_POST['email'] : null;
        $location = isset($_POST['location']) ? $_POST['location'] : null;
        $description = isset($_POST['description']) ? $_POST['description'] : null;

        // Check if all required fields are provided
        if ($name && $email && $location && $description) {
            // Prepare SQL statement to insert data into t_itrequest table
            $stmt = $conn->prepare("INSERT INTO t_itrequest (name, email, location, description, status) VALUES (:name, :email, :location, :description, 'Incomplete')");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':location', $location);
            $stmt->bindParam(':description', $description);

            // Execute the statement
            if ($stmt->execute()) {
                header("Location: ITrequestform.html?success=1");
                exit();
            } else {
                echo "Error executing query";
            }
        } else {
            echo "Error: All fields are required.";
        }
    }
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
